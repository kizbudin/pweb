<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Selamat Datang Di aplikasi CRUD</h1>
    <p> Aplikasi ini di buat untuk Sebagian Syarat Praktikum Pemrograman Web Jenjang S1 Universitas Gunadarma </p>
    <p> Klik Disini untuk Melihat : </p>
    <a class="nav-link" href="<?= base_url('mahasiswa/jadwal'); ?>">
                    <i class="fas fa-calendar-alt"></i>
                    <span>Jadwal</span></a>
    <a class="nav-link pb-0" href="<?= base_url('mahasiswa'); ?>">
                    <i class="fas fa-address-book"></i>
                    <span>Daftar Mahasiswa</span></a>
                    <br/>
    <style>.heart{color:#e25555;}</style> Made with <span class="heart">❤</span> by utari anggraini


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->